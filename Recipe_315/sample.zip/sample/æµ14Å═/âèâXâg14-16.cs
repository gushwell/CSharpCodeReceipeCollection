// ■リスト14-16：abstractキーワードを付けたVirtualPetクラス
abstract class VirtualPet  // abstractキーワードでインスタンス生成をできなくする
{
    ……
}
