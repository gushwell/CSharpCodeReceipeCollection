// ■リスト13-7：基底クラスに定義したメソッドを呼び出す
var person = new Person
{
    FirstName = "はるか",
    LastName = "佐々木",
    Email = "hsasaki@example.com"
};
person.Print();
