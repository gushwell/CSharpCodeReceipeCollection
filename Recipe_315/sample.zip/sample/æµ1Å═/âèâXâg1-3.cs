// ■リスト1-3：初めてのC#（usingディレクティブ使用）
using System;   // usingディレクティブ
class Hello
{
    static void Main()
    {
         Console.WriteLine("ようこそ、C#の世界へ");
    }
}
