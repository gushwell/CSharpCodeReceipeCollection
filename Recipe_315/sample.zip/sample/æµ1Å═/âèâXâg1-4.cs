// ■リスト1-4：初めてのC#（第2版）
using System;
class Hello
{
    static void Main()
    {
        Console.WriteLine("おはよう");
        Console.WriteLine("こんにちは");
        Console.WriteLine("さようなら");
    }
}
