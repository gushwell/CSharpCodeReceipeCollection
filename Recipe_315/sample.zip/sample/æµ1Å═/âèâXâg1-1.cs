// ■リスト1-1：初めてのC#
// Helloクラスの定義
class Hello
{
    // Mainメソッド
    static void Main()
    {
        System.Console.WriteLine("ようこそ、C#の世界へ");
    }
}
