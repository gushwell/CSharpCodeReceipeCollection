// ■リスト1-8：【×】不恰好なソースコード
using System; class  Hello {
  static  void  Main (   ) {
Console.WriteLine
("ようこそ、C#の世界へ" );}
}
