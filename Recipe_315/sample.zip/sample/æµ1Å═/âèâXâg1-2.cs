// ■リスト1-2：初めてのC#（リスト1-1再掲）
1  // Helloクラスの定義
2  class Hello
3  {
4      // Mainメソッド
5      static void Main()
6      {
7          System.Console.WriteLine("ようこそ、C#の世界へ");
8      }
9  }
