// ■リスト12-3：インデックスを指定して要素を取り出す
var str = lines[0];
Console.WriteLine(str);
