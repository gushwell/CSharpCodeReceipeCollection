// ■リスト12-30：First/Lastメソッドを使ったコード
var nums = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
var first = nums.First();  // 最初の要素を取り出す
var last = nums.Last();  // 最後の要素を取り出す
Console.WriteLine(first);
Console.WriteLine(last);
