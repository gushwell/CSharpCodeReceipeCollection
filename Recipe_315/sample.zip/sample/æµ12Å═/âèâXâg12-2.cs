// ■リスト12-2：リストに要素を追加する
var lines = new List<string>
{
    "おはよう",
    "こんにちは",
    "こんばんは",
};
lines.Add("おやすみ");  // Addメソッドで要素を追加
lines.Add("さようなら");
