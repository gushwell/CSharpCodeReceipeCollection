// ■リスト15-16：using文
using (var obj = new SampleClass())
{
    ……  // objを利用するコード
}
