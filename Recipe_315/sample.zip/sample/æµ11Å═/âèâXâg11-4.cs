// ■リスト11-4：列挙型を定義する
enum CardSuit  // enumキーワードで列挙型を定義
{
    Club,
    Spade,
    Heart,
    Diamond
}
