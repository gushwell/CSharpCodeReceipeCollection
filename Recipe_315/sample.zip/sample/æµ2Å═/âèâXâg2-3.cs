// ■リスト2-3：文字列型（string型）の変数
string name;                // 文字列型のname変数を用意
name = "山田";              // name変数に文字列を代入
Console.WriteLine("{0}さん、こんにちは", name);
Console.WriteLine("{0}さん、お久しぶりです", name);
