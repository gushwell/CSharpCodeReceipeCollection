// ■リスト2-11：空文字列
var emptyString = "";        // 長さゼロの空文字列
Console.WriteLine("1行目");
Console.WriteLine(emptyString);  // 変数emptyStringは空だが、WriteLine命令は改行を出力する
Console.WriteLine("3行目");
