// ■リスト2-10：文字列の長さを求める
var message = "おはようございます";
var length = message.Length;     // Lengthで、文字列の文字数がわかる
Console.WriteLine("{0}文字", length);
