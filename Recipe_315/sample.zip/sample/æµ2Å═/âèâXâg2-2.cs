// ■リスト2-2：変数の基本的な使い方の例
int age = 23;       // 変数の宣言と初期化
int number = 8;     // 変数の宣言と初期化
Console.WriteLine("{0}歳の人は{1}人います", age, number);
