// ■リスト2-4：変数の値を変更する（再代入）
string name = "山田";     // 変数nameを"山田"で初期化
Console.WriteLine("{0}さん、こんにちは", name);
name = "佐藤";                              // name変数に別の値を再代入
Console.WriteLine("{0}さん、お久しぶりです", name);
