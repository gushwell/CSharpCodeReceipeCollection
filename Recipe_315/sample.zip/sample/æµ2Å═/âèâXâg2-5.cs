// ■リスト2-5：演算結果を変数に代入する
int height = 8;
int width = 5;
int area;
area = height * width;  // 「*」は掛け算の記号
Console.WriteLine("面積:{0}㎡", area);
