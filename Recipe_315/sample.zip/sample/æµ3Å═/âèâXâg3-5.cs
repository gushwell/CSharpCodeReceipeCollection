// ■リスト3-5：代入の動作の確認
var num = 6;
var dup = num;
Console.WriteLine(num);
Console.WriteLine(dup);
