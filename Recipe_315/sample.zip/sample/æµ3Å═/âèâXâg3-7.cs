// ■リスト3-7：キャスト演算子による型変換の例
var perPerson = (double)total / member;  // totalをdoubleに型変換。doubleとintの演算の結果はdouble
