// ■リスト3-1：数値を扱う（再掲）
using System;
class Program
{
    static void Main()
    {
        Console.WriteLine(100 + 5);
        Console.WriteLine(100 - 5);
        Console.WriteLine(100 * 5);
        Console.WriteLine(100 / 5);
  }
}
