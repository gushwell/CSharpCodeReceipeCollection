// ■リスト3-13：+演算子による複数文字列の連結
var s1 = "おはよう。";
var s2 = "こんにちは。";
var s3 = "こんばんは。";
var s4 = "またあした。";
var str = s1 + s2 + s3 + s4;  // +演算子ではいくつでも繋げられる
Console.WriteLine(str);
