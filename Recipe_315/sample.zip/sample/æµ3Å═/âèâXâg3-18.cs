// ■リスト3-18：挿入文字列を使った文字列の組み立て（2）
var season = '夏';
var temperature = 39;
Console.WriteLine($"今年の{season}の最高気温は、{temperature}度でした。");
