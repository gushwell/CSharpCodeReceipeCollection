// ■リスト3-6：+=、*=を使った算術演算
var num = 8;
num += 2;  // numに2を加える
Console.WriteLine(num);
num *= 4;  // numを4倍する
Console.WriteLine(num);
