// ■リスト5-5：for文で回数を指定した繰り返し
var n = 5;  // 指定回数を設定
for (var i = 0; i < n; i++)  // これはn回繰り返すという慣用句
{
    Console.WriteLine($"i = {i}");
}
