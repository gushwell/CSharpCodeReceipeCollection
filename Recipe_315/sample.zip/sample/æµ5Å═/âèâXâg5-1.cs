// ■リスト5-1：【×】昭和と西暦の対応表出力プログラムをこれまでの知識で書いた例
Console.WriteLine("昭和1年 1926年");
Console.WriteLine("昭和2年 1927年");
Console.WriteLine("昭和3年 1928年");
Console.WriteLine("昭和4年 1929年");
Console.WriteLine("昭和5年 1930年");
