// ■リスト4-6：変数が範囲内かを条件AND演算子で判断するif文
var month = 6;
if (1 <= month && month <= 12)
{
    Console.WriteLine("1以上、12以下の数値です");
}
