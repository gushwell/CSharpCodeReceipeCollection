// ■リスト9-3：完全修飾名でクラスを指定する
var mapLocation = new MyApp.Map.Location();
var canvasLocation = new MyApp.Drawing.Location();
