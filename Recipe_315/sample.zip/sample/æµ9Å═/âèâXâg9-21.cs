// ■リスト9-21：現在の日時を取得する
var now = DateTime.Now;  // 現在の日時を取得する
Console.WriteLine("{0}年", now.Year);
Console.WriteLine("{0}月", now.Month);
Console.WriteLine("{0}日", now.Day);
Console.WriteLine("{0}時", now.Hour);
Console.WriteLine("{0}分", now.Minute);
Console.WriteLine("{0}秒", now.Second);
