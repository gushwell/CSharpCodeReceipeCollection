// ■リスト9-16：絶対値を求める（2）
var abs3 = Math.Abs(-5.67M);
var abs4 = Math.Abs(-1.414);
Console.WriteLine(abs3);
Console.WriteLine(abs4);
