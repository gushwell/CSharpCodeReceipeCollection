// ■リスト9-17：どちらか大きい方の数を求める
var value1 = 340;
var value2 = 500;
var max = Math.Max(value1, value2);
Console.WriteLine(max);
