// ■リスト9-5：Stringクラスのインスタンスを生成する書き方3例
var str1 = "ようこそ、C#の世界へ";

string str2 = "ようこそ、C#の世界へ";

String str3 = "ようこそ、C#の世界へ";
