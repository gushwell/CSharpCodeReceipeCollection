// ■リスト9-18：どちらか小さい方の数を求める
var value1 = 340;
var value2 = 500;
var min = Math.Min(value1, value2);
Console.WriteLine(min);
