// ■リスト9-11：文字列の一部を置き換える
var str = "インスタンスを生成せずに利用できるメソッドをstaticメソッドと言います。";
var str2 = str.Replace("staticメソッド", "静的メソッド");  // 一部の文字列を置き換える
Console.WriteLine(str2);
