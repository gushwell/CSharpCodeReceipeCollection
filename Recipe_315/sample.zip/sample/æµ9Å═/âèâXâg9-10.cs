// ■リスト9-10：文字列内の英字を小文字にする
var str = "HTML File";
var str2 = str.ToLower();  // 小文字に変更する
Console.WriteLine(str2);
