// ■リスト9-9：文字列内の英字を大文字にする
var str = "Microsoft";
var str2 = str.ToUpper();  // 大文字に変更する
Console.WriteLine(str2);
