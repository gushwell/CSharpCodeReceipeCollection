// ■リスト10-7：省略可能な仮引数
public void ExampleMethod(int required, string optionalStr = "default string")
{
    ……
}
