// ■リスト10-14：コンストラクターの呼び出し
var mypet = new VirtualPet();  // インスタンス生成時にコンストラクターが呼び出される
Console.WriteLine($"Name: {mypet.Name}");
Console.WriteLine($"Mood: {mypet.Mood}");
Console.WriteLine($"Energy: {mypet.Energy}");
