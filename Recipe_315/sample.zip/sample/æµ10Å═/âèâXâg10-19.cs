// ■リスト10-19：プロパティに動作を加える（STEP 0）
class Book
{
    ……
    public int Rating { get; set; }
    ……
}
